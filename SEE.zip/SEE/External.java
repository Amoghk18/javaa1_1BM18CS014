package SEE;
import CIE.*;
import java.util.*;
public class External extends Personal{
 public  int see[]=new int[5];
   public void set()
  {
    Scanner s=new Scanner(System.in);
    System.out.println("Enter see marks of five courses");
    for(int i=0;i<5;i++)
    see[i]=s.nextInt();
  }
}

