package CIE;
import java.util.*;
 public class Personal{
  public String usn,name;
  public int sem;  
  void set()
 {
    Scanner s=new Scanner(System.in);
    System.out.println("Enter name,usn and current sem");
    name=s.nextLine();
    usn=s.nextLine();
    sem=s.nextInt();
 }
}

