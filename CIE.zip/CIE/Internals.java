package CIE;
import java.util.*;
public class Internals extends Personal{
  public int cie[]=new int[5];
  public void set()
  {
    super.set();
    Scanner s=new Scanner(System.in);
    System.out.println("Enter cie marks of five courses");
    for(int i=0;i<5;i++)
    cie[i]=s.nextInt();
  }
}
